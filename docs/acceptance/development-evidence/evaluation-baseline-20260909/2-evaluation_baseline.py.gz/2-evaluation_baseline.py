"""Prepare and verify one pinned baseline task; no agent execution or scoring."""
import argparse
import hashlib
import json
from pathlib import Path

from evaluation_checkout import prepare_checkout
from evaluation_go_tests import verify_go_tests
from evaluation_manifest import validate
from evaluation_process import run_command
from evaluation_workspace import install_fixtures


def verify_baseline(manifest_path, task_id, repository, output, environment):
    manifest_path, output = Path(manifest_path), Path(output)
    raw = manifest_path.read_bytes()
    manifest = json.loads(raw)
    validation = validate(manifest, manifest_path.resolve().parent)
    tasks = [task for task in manifest['tasks'] if task['id'] == task_id]
    if len(tasks) != 1:
        raise ValueError('task must identify exactly one manifest entry')
    if not output.is_absolute() or output != output.resolve():
        raise ValueError('output must be absolute without symlink components')
    task = tasks[0]
    output.mkdir(mode=0o700)
    report = dict(schema_version=1, status='preparing', task=task_id,
                  manifest_sha256=hashlib.sha256(raw).hexdigest(),
                  catalogue_status=validation['status'], repository=task['repository'],
                  environment_keys=sorted(environment), checks=[],
                  limitations=['Baseline verification only; no agent changes, model calls or task-success scoring.',
                      'Local command execution is not an isolation sandbox; use only reviewed offline baseline commands.',
                      'Independent review and all comparative acceptance gates remain required.'])
    workspace = output/'workspace'
    try:
        report['preparation'] = prepare_checkout(repository, task['repository']['commit'], workspace)
        report['fixtures'] = install_fixtures(manifest_path.resolve().parent, workspace, task['fixtures'])
        cwd = workspace/task['working_directory']
        if cwd != cwd.resolve() or not cwd.is_dir():
            raise ValueError('verification working directory is unavailable or not contained')
        for index, check in enumerate(task['verification']):
            execution = run_command(check['argv'], cwd, output/('check-'+str(index)),
                                    check['timeout_seconds'], 16 << 20, environment)
            stdout = Path(execution['logs']['stdout']['path']).read_text()
            verification = verify_go_tests(stdout, execution, check['expected_tests'])
            report['checks'].append(dict(execution=execution, verification=verification))
        report['status'] = 'baseline_tests_passed' if all(c['verification']['status'] == 'passed'
                                                        for c in report['checks']) else 'baseline_tests_failed'
    except Exception as error:
        report['status'] = 'baseline_error'
        report['error'] = dict(type=type(error).__name__, message=str(error))
        raise
    finally:
        with (output/'report.json').open('x') as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
            stream.write('\n')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('--task', required=True)
    parser.add_argument('--repository', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--environment', type=Path, required=True,
                        help='explicit JSON environment mapping; never include model credentials')
    args = parser.parse_args()
    report = verify_baseline(args.manifest, args.task, args.repository, args.output,
                             json.loads(args.environment.read_text()))
    print(json.dumps(dict(status=report['status'], report=str(args.output/'report.json'))))
    return 0 if report['status'] == 'baseline_tests_passed' else 1


if __name__ == '__main__': raise SystemExit(main())
