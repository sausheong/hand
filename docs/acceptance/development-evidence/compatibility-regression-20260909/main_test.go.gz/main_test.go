package main

import (
	"context"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// Exercise the shipped example itself against a freshly built Hand. The
// example verifies six real interface journeys, exact terminal counts and
// provider cancellation, using only its local deterministic HTTP provider.
func TestCompatibilityAcrossPublicInterfaces(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Minute)
	defer cancel()
	binary := filepath.Join(t.TempDir(), "hand")
	build := exec.CommandContext(ctx, "go", "build", "-o", binary, "./cmd/hand")
	build.Dir = "../.."
	if output, err := build.CombinedOutput(); err != nil {
		t.Fatalf("build Hand: %v\n%s", err, output)
	}
	if err := run(binary); err != nil {
		t.Fatal(err)
	}
}

func TestCompatibilityMissingBinaryCannotReportSuccess(t *testing.T) {
	err := run(filepath.Join(t.TempDir(), "missing-hand"))
	if err == nil || !strings.Contains(err.Error(), "CLI failed") {
		t.Fatalf("missing binary did not fail CLI journey: %v", err)
	}
}
