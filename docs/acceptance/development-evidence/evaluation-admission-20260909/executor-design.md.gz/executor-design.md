# Paired evaluation executor: remaining implementation contract

Status: design informed by source review, not an implemented or authorised executor.
Date: 9 September 2026.

Implemented component: `scripts/evaluation_pi_events.py` now observes a bounded
RPC stream for one fresh run. Feed raw byte chunks to `PiRunObserver`; use
`ready_for_stats` to decide when to request the separately correlated final
statistics, then `finish()` to obtain an `observed_unverified` or `incomplete`
report. It separates reported cost from verified billing. The executor must
still supply actual Pi I/O, timeout/cancellation, process joins and spending
enforcement. Synthetic observer tests do not qualify the Pi runtime. Evidence:
[pi-observer.json](../pi-observer.json).

The separate `scripts/check_pi_offline.py` probe now exercises the published
0.85.1 npm runtime with a deterministic custom provider, fresh homes/workspaces,
and no model credentials. Success, automatic retry and abort all passed; actual
event streams are retained as observer regression fixtures. Package integrity
matches registry metadata. This verifies those local RPC behaviours, not the
complete comparison adapter or spending boundary. See [pi-runtime.json](../pi-runtime.json).

## Competitor candidate

The official site links to `earendil-works/pi`. The release reviewed here is
v0.85.1, commit `d981de1229ef899957bbe968bc8dcda02a21f477`. Its package is
`@earendil-works/pi-coding-agent`, with Node >=22.19.0 and CLI entry
`dist/bundle/cli.js`. This is a proposed comparison pin; local source, dependencies
and executable bytes still need qualification. See [source-review record](../pi-source-review.json),
[official site](https://pi.dev),
[release](https://github.com/earendil-works/pi/releases/tag/v0.85.1) and
[pinned package metadata](https://raw.githubusercontent.com/earendil-works/pi/d981de1229ef899957bbe968bc8dcda02a21f477/packages/coding-agent/package.json).

## Lifecycle requirements

Pi's prompt response acknowledges admission, not completion. `agent_end` can
precede retries or continuations; `agent_settled` identifies completed automatic
activity. `get_session_stats` includes assistant, tool-reported, and summarisation
usage. Queue clearing and abort are separate operations. These documented
distinctions must be tested against the actual pinned runtime.
[Release RPC documentation](https://raw.githubusercontent.com/earendil-works/pi/v0.85.1/packages/coding-agent/docs/rpc.md).

The executor must implement and test:

1. Start each arm with a fresh isolated home, workspace and session. Record
   resolved model identity, settings, tools, source trees and executable digests.
2. Correlate prompt admission with its request ID. Rejection is a failed attempt.
   Never start another scheduled task in that session.
3. Continue collecting events through retry, compaction and queued continuations.
   Do not infer success from a transport acknowledgement or intermediate end.
4. At settlement, collect accounting, close and join the process tree, preserve
   its workspace changes, and run the independent frozen verification fixtures.
   Agent completion is distinct from task success, which also requires review.
5. On timeout, cancellation or budget exhaustion, revoke access to the provider
   first, clear queued work, abort and join. Retain the failed attempt in the
   denominator. Missing final usage remains uncertain rather than zero.

## Spending enforcement

Implemented quote component: `scripts/evaluation_quote.py` accepts an explicit
versioned contract with provider/model identity, source digest, context/output
limits, all applicable complete token-price sets, and a maximum per-request fee.
Rates are exact decimal USD strings per million tokens. It reserves the complete
input context at the highest input/cache rate, plus the enforced output cap at
the highest output rate and the fee, rounding upward to integer billionths of a
USD. Missing categories, unknown billing semantics, model mismatch, impossible
output caps and numeric overflow are rejected. Contract hashes bind all inputs.

This method supports text-token billing with input/cache counts normalised into
disjoint categories. It depends on verified provider limits and complete pricing
tiers/fees. It does not establish those facts itself. The gateway must reject
unsupported billing, payload types, service tiers or endpoint/model changes and
enforce the quoted output limit on the forwarded request. A full-context quote
may exceed a budget even for a short prompt. Do not silently reduce it: obtain
an independently justified tighter bound or size the approved budget accordingly.
No actual provider catalogue or spending approval is supplied by this component.

Implemented storage component: `scripts/evaluation_budget.py` provides SQLite
reservations bound to one manifest digest. Each forwarding attempt needs a new
request identity; the transaction commits before admission returns. Outstanding
or uncertain calls retain their full input/output/cost bounds after restart.
Known usage releases only the unused reservation; request slots remain consumed.
Revocation and observed expiry stop further admission permanently, including after clock rollback. Stored limits and reservation states are validated on open and before writes; malformed records fail closed. Conflicting usage or an exceeded
bound persist an audit record and block all new reservations. Amounts use integer
billionths of a USD, avoiding floating-point balance arithmetic.

Quoted admission now also stores the SHA-256 of the exact outbound body bytes,
the complete canonical pricing contract and provider/model identity in the same
transaction as the reservation. `reserve_quoted` returns only after both records
commit; `binding` retrieves reconciliation evidence and never grants permission
to replay a request. Reopening and subsequent writes recompute the quote and
reject a mismatch with the stored bounds. Request bodies and credentials are not
stored. A raw numeric `reserve` remains a lower-level primitive and carries no
such binding; the future provider gateway must use quoted admission.

The caller must validate the actual provider payload and endpoint and forward
exactly the hashed bytes with the quoted output limit. This storage change does
not perform that validation or authenticate pricing. Legacy development ledgers
without the binding table are rejected; preserve them for reconciliation rather
than deleting/recreating a budget. No paid ledger has been migrated or reset.

This is not an authorisation mechanism. The caller must verify approval, bind run
IDs to the frozen schedule, establish defensible bounds, enforce monotonic request
timeouts and isolate the ledger from agents. It must also authenticate usage
evidence before settlement; a digest alone does not prove billing. The ledger
does not forward requests, price models, enforce network routing or automatically
resolve an ambiguous charge. Those gateway responsibilities remain unfinished.

The release supports provider `baseUrl` overrides, which can route requests
through an evaluation gateway without redefining all models. Configuration alone
does not prove that every request is intercepted or bounded.
[Release model documentation](https://raw.githubusercontent.com/earendil-works/pi/v0.85.1/packages/coding-agent/docs/models.md).

Implement a shared boundary for both arms, with provider credentials held outside
agent workspaces. Agent containers must have no alternative provider route or
inherited credentials. The gateway must enforce the approved aggregate cap and
per-run request, token, cost and time caps before forwarding requests. It must
reserve a defensible upper bound on each request, including output/reasoning and
applicable input/cache pricing, and reject unknown pricing or unbounded requests.
Do not treat an approximate local token count as a proven input bound.

Record reservations durably before forwarding. Interrupted or ambiguous requests
retain their reserved amount until reconciled. Retries consume new reservations;
restarting an executor must not reset a budget. Summary and nested tool calls
must pass the same boundary. Provider usage, gateway records and agent-reported
totals must be reconciled without double-counting cache tokens.

This requires real fault tests: concurrent final-budget requests, crash after
forwarding, missing usage, retry after timeout, disconnect during streaming,
attempted endpoint bypass, restart with a pending reservation, and revoked run
credentials. A final-statistics parser or process timeout cannot replace these
controls. No gateway or paid-run authorisation is supplied by this document.

## Fairness and integration

Apply the same external enforcement to both default and configured arms. Preserve
their actual product defaults within those explicit experimental limits and
report all deviations. Do not silently disable one agent's retries or compaction
to simplify accounting. Freeze configurations before held-out runs; tuning after
inspection requires a new comparison design, not relabelling exposed tasks.

Reuse the existing schedule, checkout, fixture-integrity, bounded-process and
result-reporting modules. Connect them only after actual runtime adapters,
isolation and gateway controls pass. The current five-task calibration catalogue
is still too small and has no held-out tasks. The required 30-task corpus, ten
held-out tasks, both modes, three repetitions and independent scoring all remain
mandatory. Native-provider smoke tests remain a separate acceptance requirement.
