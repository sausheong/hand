package tui

import (
	"context"
	"errors"
	tea "github.com/charmbracelet/bubbletea"
	teatest "github.com/charmbracelet/x/exp/teatest"
	"github.com/sausheong/hand/internal/agentio"
	"github.com/sausheong/hand/internal/config"
	"github.com/sausheong/harness/llm"
	"github.com/sausheong/harness/runtime"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestFinalIterationStillRunsValidation(t *testing.T) {
	m := NewModel(&fakeRunner{}, t.TempDir())
	m.SetGoalLoop([]config.HookConfig{{Event: "Stop", Command: "sh", Args: []string{"-c", "exit 0"}}}, nil, 1)
	m.goalIteration = 1
	if cmd := m.maybeContinueGoalLoop(); cmd == nil {
		t.Fatal("final iteration skipped validation, so success cannot be established")
	}
}

func TestTUIOneTerminalOutcome(t *testing.T) {
	for _, tc := range []struct {
		name, reason string
		event        runtime.AgentEvent
		hooks        []config.HookConfig
		cancel       bool
		want         agentio.RunStatus
		verified     bool
	}{
		{name: "answer", reason: "completed", event: runtime.AgentEvent{Type: runtime.EventDone}, want: agentio.Completed},
		{name: "final success", reason: "completed", event: runtime.AgentEvent{Type: runtime.EventDone}, hooks: []config.HookConfig{{Event: "Stop", Command: "sh", Args: []string{"-c", "exit 0"}}}, want: agentio.Completed, verified: true},
		{name: "final incomplete", reason: "completed", event: runtime.AgentEvent{Type: runtime.EventDone}, hooks: []config.HookConfig{{Event: "Stop", Command: "sh", Args: []string{"-c", "exit 2"}}}, want: agentio.BudgetExhausted},
		{name: "validator failure", reason: "completed", event: runtime.AgentEvent{Type: runtime.EventDone}, hooks: []config.HookConfig{{Event: "Stop", Command: "sh", Args: []string{"-c", "exit 1"}}}, want: agentio.VerificationFailed},
		{name: "runtime error", reason: "error", event: runtime.AgentEvent{Type: runtime.EventError, Error: errors.New("provider failed")}, want: agentio.InfrastructureError},
		{name: "turn limit", reason: "max_turns", event: runtime.AgentEvent{Type: runtime.EventError, Error: errors.New("limit")}, want: agentio.BudgetExhausted},
		{name: "cancel", reason: "completed", event: runtime.AgentEvent{Type: runtime.EventDone}, cancel: true, want: agentio.Cancelled},
		{name: "missing completion", reason: "error", event: runtime.AgentEvent{Type: runtime.EventTextDelta, Text: "unfinished"}, want: agentio.InfrastructureError},
	} {
		t.Run(tc.name, func(t *testing.T) {
			m := NewModel(&fakeRunner{}, t.TempDir())
			m.running = true
			m.goalActive = true
			m.goalIteration = 1
			m.SetGoalLoop(tc.hooks, &tc.reason, 1)
			m.Update(runEventMsg{identity: m.identity, event: tc.event})
			m.goalCancelled = tc.cancel
			_, cmd := m.Update(runEndedMsg{identity: m.identity})
			if cmd != nil {
				msg := cmd()
				m.Update(msg)
				m.Update(msg)
			}
			m.Update(runEndedMsg{identity: m.identity})
			if m.lastOutcome == nil || m.lastOutcome.Status != tc.want || m.lastOutcome.Verified != tc.verified {
				t.Fatalf("outcome %+v, want %s verified=%v", m.lastOutcome, tc.want, tc.verified)
			}
			if n := strings.Count(strings.Join(m.transcript, "\n"), "[result]"); n != 1 {
				t.Fatalf("published %d outcomes", n)
			}
		})
	}
}

func TestTUICancelledCheckCannotPublishSuccess(t *testing.T) {
	m := NewModel(&fakeRunner{}, t.TempDir())
	m.goalActive = true
	m.goalIteration = 1
	m.SetGoalLoop([]config.HookConfig{{Event: "Stop", Command: "sh", Args: []string{"-c", "exit 0"}}}, nil, 2)
	cmd := m.maybeContinueGoalLoop()
	msg := cmd()
	m.handleKey(tea.KeyMsg{Type: tea.KeyCtrlC})
	m.Update(msg)
	if m.lastOutcome == nil || m.lastOutcome.Status != agentio.Cancelled {
		t.Fatalf("outcome %+v", m.lastOutcome)
	}
	if n := strings.Count(strings.Join(m.transcript, "\n"), "[result]"); n != 1 {
		t.Fatalf("published %d outcomes", n)
	}
}

func TestInteractiveRequestPublishesCompletion(t *testing.T) {
	events := make(chan runtime.AgentEvent, 2)
	events <- runtime.AgentEvent{Type: runtime.EventTextDelta, Text: "answer"}
	events <- runtime.AgentEvent{Type: runtime.EventDone}
	close(events)
	m := NewModel(&fakeRunner{events: events}, t.TempDir())
	tm := teatest.NewTestModel(t, m, teatest.WithInitialTermSize(100, 30))
	m.BindProgram(tm.GetProgram())
	tm.Type("hello")
	tm.Send(tea.KeyMsg{Type: tea.KeyEnter})
	teatest.WaitFor(t, tm.Output(), func(b []byte) bool { return strings.Contains(string(b), "[result] Completed") }, teatest.WithDuration(2*time.Second))
	tm.Send(tea.KeyMsg{Type: tea.KeyCtrlC})
	tm.WaitFinished(t, teatest.WithFinalTimeout(2*time.Second))
	if m.lastOutcome == nil || m.lastOutcome.Status != agentio.Completed {
		t.Fatalf("outcome %+v", m.lastOutcome)
	}
	if n := strings.Count(strings.Join(m.transcript, "\n"), "[result]"); n != 1 {
		t.Fatalf("published %d outcomes", n)
	}
}

type freshAnswerRunner struct{}

func (freshAnswerRunner) Run(context.Context, string, []llm.ImageContent) (<-chan runtime.AgentEvent, error) {
	events := make(chan runtime.AgentEvent, 2)
	events <- runtime.AgentEvent{Type: runtime.EventTextDelta, Text: "answer"}
	events <- runtime.AgentEvent{Type: runtime.EventDone}
	close(events)
	return events, nil
}

func TestInteractiveContinuationPublishesOneFinalResult(t *testing.T) {
	m := NewModel(freshAnswerRunner{}, t.TempDir())
	marker := filepath.Join(t.TempDir(), "first-check")
	m.SetGoalLoop([]config.HookConfig{{Event: "Stop", Command: "sh", Args: []string{"-c", `if test -f "$1"; then exit 0; else : > "$1"; exit 2; fi`, "hook", marker}}}, nil, 2)
	tm := teatest.NewTestModel(t, m, teatest.WithInitialTermSize(120, 35))
	m.BindProgram(tm.GetProgram())
	tm.Type("finish the task")
	tm.Send(tea.KeyMsg{Type: tea.KeyEnter})
	teatest.WaitFor(t, tm.Output(), func(b []byte) bool { return strings.Contains(string(b), "configured checks passed") }, teatest.WithDuration(3*time.Second))
	tm.Send(tea.KeyMsg{Type: tea.KeyCtrlC})
	tm.WaitFinished(t, teatest.WithFinalTimeout(2*time.Second))
	if m.lastOutcome == nil || !m.lastOutcome.Verified || m.lastOutcome.Iterations != 2 {
		t.Fatalf("outcome %+v", m.lastOutcome)
	}
	if n := strings.Count(strings.Join(m.transcript, "\n"), "[result]"); n != 1 {
		t.Fatalf("published %d outcomes", n)
	}
}
