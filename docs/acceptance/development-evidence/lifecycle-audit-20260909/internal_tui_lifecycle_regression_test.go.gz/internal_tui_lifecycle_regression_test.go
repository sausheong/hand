package tui

import (
	"context"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/sausheong/hand/internal/agentio"
	"github.com/sausheong/hand/internal/config"
	"github.com/sausheong/harness/runtime"
	"testing"
)

func TestCancelledGoalResultCannotContinue(t *testing.T) {
	runner := &fakeRunner{}
	m := NewModel(runner, t.TempDir())
	m.goalCancelled = true
	m.Update(goalLoopResultMsg{identity: m.identity, outcome: agentio.GoalLoopOutcome{Continue: true, NextPrompt: "obsolete"}})
	if runner.getLastMsg() != "" {
		t.Fatal("cancelled goal started another run")
	}
}

func TestSupersededGoalCheckCannotContinue(t *testing.T) {
	for _, action := range []string{"cancel", "new input", "new check"} {
		t.Run(action, func(t *testing.T) {
			runner := &fakeRunner{}
			m := NewModel(runner, t.TempDir())
			m.goalHooks = []config.HookConfig{{Event: "Stop", Command: "sh", Args: []string{"-c", "echo obsolete; exit 2"}}}
			m.goalIteration = 1
			m.goalMaxIterations = 10
			cmd := m.maybeContinueGoalLoop()
			if cmd == nil || !m.goalChecking {
				t.Fatal("check was not scheduled")
			}
			// Queue a real completed subprocess result, then supersede it before delivery.
			result := cmd()
			switch action {
			case "cancel":
				m.handleKey(tea.KeyMsg{Type: tea.KeyCtrlC})
			case "new input":
				m.startRun("new work")
			case "new check":
				m.maybeContinueGoalLoop()
			}
			before := runner.getLastMsg()
			m.Update(result)
			if runner.getLastMsg() != before {
				t.Fatal("obsolete hook result started work")
			}
			m.cancelGoalCheck()
		})
	}
}

func TestCancelGoalCheckCancelsContextAndInvalidatesResults(t *testing.T) {
	m := NewModel(&fakeRunner{}, t.TempDir())
	ctx, cancel := context.WithCancel(context.Background())
	m.goalChecking = true
	m.goalCheckCancel = cancel
	generation := m.goalGeneration
	m.handleKey(tea.KeyMsg{Type: tea.KeyCtrlC})
	if ctx.Err() == nil || m.goalChecking || m.goalGeneration == generation {
		t.Fatal("cancellation did not terminate and invalidate check")
	}
}

func TestGoalResultConsumedOnlyOnce(t *testing.T) {
	m := NewModel(&fakeRunner{}, t.TempDir())
	m.goalIteration = 1
	msg := goalLoopResultMsg{identity: m.identity, outcome: agentio.GoalLoopOutcome{Continue: true, NextPrompt: "next"}}
	m.Update(msg)
	m.Update(msg)
	if m.goalIteration != 2 {
		t.Fatalf("duplicate continuation: iteration %d", m.goalIteration)
	}
}

func TestEventDoneDoesNotReleaseRuntimeBeforeChannelCloses(t *testing.T) {
	m := NewModel(&fakeRunner{}, t.TempDir())
	m.running = true
	m.handleAgentEvent(runtime.AgentEvent{Type: runtime.EventDone})
	if !m.running {
		t.Fatal("EventDone released runtime while deferred work may still hold it")
	}
}
