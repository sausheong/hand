# Current Harness review snapshot

This is a development review bundle, not a released version. Publication is not authorised.

The [current cumulative patch](development-evidence/harness-current-20260909/harness-current.patch) applies to historical base `09c30fe2d529d6125f423593f621e970a7ce8735` and includes the budget ambiguity and required-field fixes. It reconstructs all 297 files in the integrated working tree at source HEAD `5998569d24ce063207cc237263d89f22d532e25f`, including uncommitted changes. The [manifest](harness-current-review.json) records file hashes, executable modes and exact source identity. Earlier review patches remain historical; do not stack them on this cumulative patch.

Patch SHA-256: `873c7e69a94293bdb0071c1f381f4fd171218a6483e0f09284e8f40e70167ac1`.
Source fingerprint: `94d7b04316cab30fdf614e2f6db6bc6328091be5082cca562b51688c600487f9`.

The patch passed indexed apply checking and actual application in a fresh reconstruction. All file bytes and modes matched the source; the source tree and original index were unchanged. `go vet ./...` passed in the reconstruction with `GOWORK=off`.

The [fresh full native suite](harness-current-native-suite.json) passed 1111 test/subtest records across 32 packages with no failures/skips, race detection and cross-package coverage. Its source fingerprint matches this patch exactly. Budget and Hand usage decoders also completed 60-second fuzz runs. The [refreshed full Hand suite](budget-native-suite.json) also passes against this exact Harness source. This remains development evidence; clean-candidate, released-dependency and final acceptance qualification are pending.

Before release, refresh upstream refs, review the cumulative changes, qualify the exact candidate on supported native platforms and obtain publication authorisation. Do not assume a proposed version is available, replace tags or force-push main. After authorised publication, pin Hand to the actual released module/checksum, remove its local workspace override and collect all final evidence for a clean Hand candidate. Coverage thresholds, scenario qualification and authorised comparative evaluation remain open.
