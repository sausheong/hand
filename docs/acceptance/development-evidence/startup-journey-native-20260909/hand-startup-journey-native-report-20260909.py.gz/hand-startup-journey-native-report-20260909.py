from pathlib import Path
import json,sys,collections,gzip,hashlib
root=Path('/Users/sausheong/projects/hand');sys.path.insert(0,str(root/'scripts'))
from evidence import coverage_metrics
from coverage_changes import changed_lines,changed_coverage,classify_changed_sources
from critical_coverage import critical_coverage
raw=Path('/private/tmp/hand-startup-journey-native-20260909-result.json');run=json.loads(raw.read_text());assert run['exit_code']==0 and run['source_before']==run['source_after']
records=[json.loads(x) for x in Path('/private/tmp/hand-startup-journey-native-20260909.jsonl').read_text().splitlines() if x.startswith('{')]
counts=collections.Counter(r['Action'] for r in records if r.get('Test') and r['Action'] in ['pass','fail','skip']);pkgs=collections.Counter(r['Action'] for r in records if not r.get('Test') and r['Action'] in ['pass','fail','skip']);assert not counts['fail'] and not counts['skip'] and pkgs=={'pass':26}
harness_evidence=json.loads((root/'docs/acceptance/catalogue-harness-suite.json').read_text())
assert run['source_after']['/private/tmp/hand-harness-persistence-20260908']['sha256']=='c52ab17e0f872e75f337d82107817e96418bab6e16220cd9021b4b3f2a6e6a4b'
profile=Path('/private/tmp/hand-startup-journey-native-20260909.cover').read_text();coverage=coverage_metrics(profile)
changes=classify_changed_sources(root,changed_lines(root,'e6dd263'),json.loads((root/'docs/acceptance/coverage-scope.json').read_text()))['production_changes']; changed=changed_coverage(profile,'github.com/sausheong/hand',changes,root=root)
mapping=json.loads((root/'docs/acceptance/critical-coverage-map.json').read_text());groups=critical_coverage({'github.com/sausheong/hand':profile,'github.com/sausheong/harness':Path('/private/tmp/hand-catalogue-harness-20260909.cover').read_text()},mapping)
for g in groups.values():g.pop('blocks',None)
out=root/'docs/acceptance/development-evidence/startup-journey-native-20260909';out.mkdir(parents=True,exist_ok=True)
for p in [raw,Path('/private/tmp/hand-startup-journey-native-20260909.jsonl'),Path('/private/tmp/hand-startup-journey-native-20260909.cover'),Path('/private/tmp/hand-startup-journey-native-suite-20260909.py')]:
 dest=out/(p.name+'.gz');dest.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
report={k:run[k] for k in ['environment','fixtures','fixture_builds','command','exit_code','seconds']};report.update(status='development_full_hand_suite_passed',profiles_current=True,sources_unchanged=True,source_hashes={k:v['sha256'] for k,v in run['source_before'].items()},test_records=dict(counts),packages=dict(pkgs),coverage=coverage,changed_coverage=changed,critical_groups=groups,limitations=['Dirty native macOS development checkout with local Harness; not final candidate','Other platform runtime profiles and released Harness qualification remain open','Final coverage qualification requires all platform profiles and exact released-candidate evidence'],artifacts=[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.iterdir())])
for name in ['startup-journey-native-suite.json','current-native-suite.json']:(root/'docs/acceptance'/name).write_text(json.dumps(report,indent=2)+'\n')
p=root/'docs/acceptance/current-critical-coverage.json';old=json.loads(p.read_text());old.update(groups=groups,profiles_current=True,evidence=['docs/acceptance/startup-journey-native-suite.json','docs/acceptance/catalogue-harness-suite.json'],refresh_reason='Native suite refresh after startup lifecycle extraction and compiled CLI/SDK coding journeys.');p.write_text(json.dumps(old,indent=2)+'\n')
p=root/'docs/acceptance/progress.json';d=json.loads(p.read_text())
for r in d['requirements']:
 if r['id'] in ['M0.1','M1.1','M2.1','M3.1','G-TEST'] and 'docs/acceptance/startup-journey-native-suite.json' not in r['evidence']:r['evidence'].append('docs/acceptance/startup-journey-native-suite.json')
p.write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({'tests':dict(counts),'packages':dict(pkgs),'coverage':coverage['total'],'changed':{k:v for k,v in changed.items() if k in ['percentage','status','missing_profile_files']},'critical':{k:v['observed_percentage'] for k,v in groups.items()}},indent=2))
