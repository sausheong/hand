package app

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/sausheong/harness/runtime"
)

func TestStartupCancelledBuilderCannotTransferRuntime(t *testing.T) {
	started, release := make(chan struct{}), make(chan struct{})
	a := NewStartupAttempt(context.Background(), time.Minute, func(context.Context) (*runtime.Runtime, error) {
		close(started)
		<-release
		return &runtime.Runtime{}, nil // A builder may finish successfully after cancellation.
	})
	a.Start()
	<-started
	a.Cancel()
	select {
	case <-a.Done():
		t.Fatal("cancellation reported completion before construction joined")
	default:
	}
	close(release)
	rt, err := a.Finish(nil)
	if rt != nil || !errors.Is(err, context.Canceled) {
		t.Fatalf("cancelled runtime transferred: %v %v", rt, err)
	}
}

func TestStartupRejectsMissingResultAndPreservesDisconnect(t *testing.T) {
	for _, build := range []func(context.Context) (*runtime.Runtime, error){nil,
		func(context.Context) (*runtime.Runtime, error) { return nil, nil }} {
		a := NewStartupAttempt(context.Background(), time.Minute, build)
		a.Start()
		<-a.Done()
		if a.Err() == nil {
			t.Fatal("missing runtime accepted")
		}
		disconnect := errors.New("disconnected")
		if rt, err := a.Finish(disconnect); rt != nil || !errors.Is(err, disconnect) {
			t.Fatalf("disconnect lost: %v %v", rt, err)
		}
	}
}
