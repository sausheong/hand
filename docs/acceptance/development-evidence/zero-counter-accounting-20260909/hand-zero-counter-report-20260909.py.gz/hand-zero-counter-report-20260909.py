from pathlib import Path
import sys,json,hashlib,gzip
root=Path('/Users/sausheong/projects/hand');sys.path.insert(0,str(root/'scripts'))
from coverage_changes import changed_coverage
from evidence import source_snapshot
prior=json.loads((root/'docs/acceptance/lifecycle-fixed-native-suite.json').read_text())
run=json.loads(Path('/private/tmp/hand-lifecycle-fixed-native-20260909-result.json').read_text())
def go_inputs(snapshot):
 return [e for e in snapshot['entries'] if e['path'].endswith('.go') or e['path'] in ('go.mod','go.sum','go.work','go.work.sum')]
assert go_inputs(source_snapshot(root)) == go_inputs(run['source_after'][str(root)])
profile=Path('/private/tmp/hand-lifecycle-fixed-native-20260909.cover')
report=changed_coverage(profile.read_text(),'github.com/sausheong/hand',prior['changed_coverage']['changed_lines'],root=root)
assert report['percentage']==prior['changed_coverage']['percentage']
assert [x['path'] for x in report['zero_counter_sources']]==['internal/tui/events.go']
assert len(report['missing_profile_files'])==6
out=root/'docs/acceptance/development-evidence/zero-counter-accounting-20260909';out.mkdir(parents=True,exist_ok=True)
artifacts=[]
for p in [Path(__file__),Path('/private/tmp/hand-zero-counter-coverage-20260909.log'),Path('/private/tmp/hand-zero-counter-validate-20260909.log'),root/'scripts/coverage_changes.py',root/'scripts/test_coverage_changes.py',root/'scripts/validate.py']:
 dest=out/(p.name+'.gz');dest.write_bytes(gzip.compress(p.read_bytes(),mtime=0));artifacts.append(dict(path=str(dest.relative_to(root)),sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
evidence=dict(status='development_accounting_verified',changed_coverage=report,profile_sha256=hashlib.sha256(profile.read_bytes()).hexdigest(),profile_evidence='docs/acceptance/lifecycle-fixed-native-suite.json',go_inputs_unchanged=True,tests={'coverage_reporter':9,'validation_runner':6,'failures':0},artifacts=artifacts,limitations=['Recomputed existing authentic native profile; no new full Go suite run','Six executable platform files remain missing; no coverage scope waiver applied','Dirty checkout and local Harness remain unqualified for final acceptance'])
(root/'docs/acceptance/zero-counter-accounting.json').write_text(json.dumps(evidence,indent=2)+'\n')
p=root/'docs/acceptance/current-native-suite.json';current=json.loads(p.read_text());current['changed_coverage']=report;current['accounting_refresh']='docs/acceptance/zero-counter-accounting.json';p.write_text(json.dumps(current,indent=2)+'\n')
p=root/'docs/acceptance/progress.json';progress=json.loads(p.read_text())
for item in progress['requirements']:
 if item['id'] in ('M0.1','G-TEST') and 'docs/acceptance/zero-counter-accounting.json' not in item['evidence']:item['evidence'].append('docs/acceptance/zero-counter-accounting.json')
p.write_text(json.dumps(progress,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('status','percentage','missing_profile_files','zero_counter_sources')},indent=2))
