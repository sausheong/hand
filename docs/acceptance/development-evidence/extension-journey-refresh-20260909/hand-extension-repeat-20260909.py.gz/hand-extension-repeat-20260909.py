from pathlib import Path
import json,os,subprocess,time,sys
root=Path('/Users/sausheong/projects/hand');sys.path.insert(0,str(root/'scripts'))
from evidence import source_snapshot
roots=[root,Path('/private/tmp/hand-harness-persistence-20260908')]
result={'before':{str(p):source_snapshot(p) for p in roots},'runs':[]}
command=json.loads(Path('/private/tmp/hand-extension-refresh-result-20260909.json').read_text())['commands'][-1]['command']
for i in range(20):
 out='/private/tmp/hand-extension-repeat-'+str(i)+'-20260909';cmd=command[:-1]+[out];start=time.monotonic()
 with open(out+'.log','wb') as f:r=subprocess.run(cmd,cwd=root,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=f,stderr=subprocess.STDOUT)
 result['runs'].append({'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'out':out})
 if r.returncode:break
result['after']={str(p):source_snapshot(p) for p in roots};result['sources_unchanged']=result['before']==result['after']
Path('/private/tmp/hand-extension-repeat-result-20260909.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'runs':len(result['runs']),'exit_code':r.returncode,'sources_unchanged':result['sources_unchanged']}));sys.exit(r.returncode)
