from pathlib import Path
import sys,os,json,subprocess,time
root=Path('/Users/sausheong/projects/hand');sys.path.insert(0,str(root/'scripts'))
from evidence import source_snapshot
roots=[root,Path('/private/tmp/hand-harness-persistence-20260908')]
report={'before':{str(p):source_snapshot(p) for p in roots},'commands':[]}
env={**os.environ,'GOCACHE':'/private/tmp/hand-review-gocache','GOPROXY':'off','PYTHONDONTWRITEBYTECODE':'1'}
commands=[['go','build','-o','/private/tmp/hand-extension-refresh-cli-20260909','./cmd/hand'],['go','build','-o','/private/tmp/hand-extension-refresh-peer-20260909','./examples/extensions/go-task-note'],['/opt/homebrew/bin/python3','scripts/check_extension_rpc.py','--hand-binary','/private/tmp/hand-extension-refresh-cli-20260909','--go-extension','/private/tmp/hand-extension-refresh-peer-20260909','--python-binary','/opt/homebrew/bin/python3','--python-source',str(root/'examples/extensions/python-task-note/main.py'),'--out','/private/tmp/hand-extension-refresh-rpc-20260909']]
for i,command in enumerate(commands):
 start=time.monotonic()
 with open('/private/tmp/hand-extension-refresh-'+str(i)+'-20260909.log','wb') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 report['commands'].append({'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start})
 if r.returncode:break
report['after']={str(p):source_snapshot(p) for p in roots};report['sources_unchanged']=report['before']==report['after']
Path('/private/tmp/hand-extension-refresh-result-20260909.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'commands':report['commands'],'sources_unchanged':report['sources_unchanged']}));sys.exit(r.returncode)
