package tui

import (
	"context"
	"errors"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/sausheong/hand/internal/agentio"
	"github.com/sausheong/hand/internal/app"
	"github.com/sausheong/hand/internal/config"
	"testing"
	"time"
)

func TestCancelledGoalResultCannotContinue(t *testing.T) {
	started := make(chan struct{})
	calls := 0
	backend := applicationBackend{run: func(ctx context.Context, _ string) (<-chan app.BackendEvent, error) {
		calls++
		events := make(chan app.BackendEvent)
		go func() { close(started); <-ctx.Done(); close(events) }()
		return events, nil
	}}
	service := app.New(backend, app.Options{MaxIterations: 2})
	m := applicationModel(t, service, t.TempDir())
	cmd := m.startRun("cancel")
	old := m.activeStream
	<-started
	m.handleKey(tea.KeyMsg{Type: tea.KeyCtrlC})
	driveApplication(t, m, cmd)
	before := len(m.transcript)
	m.Update(applicationMsg{stream: old, event: app.Event{Kind: "continuation", Iteration: 2, Text: "obsolete"}})
	success := agentio.RunOutcome{Status: agentio.Completed, Verified: true}
	m.Update(applicationMsg{stream: old, outcome: &success})
	if calls != 1 || m.running || m.lastOutcome == nil || m.lastOutcome.Status != agentio.Cancelled || len(m.transcript) != before {
		t.Fatal("cancelled stream changed the settled run", calls, m.lastOutcome)
	}
}

func TestSupersededGoalCheckCannotContinue(t *testing.T) {
	for _, action := range []string{"cancel", "new input", "new check"} {
		t.Run(action, func(t *testing.T) {
			runner := &fakeRunner{}
			m := NewModel(runner, t.TempDir())
			m.goalHooks = []config.HookConfig{{Event: "Stop", Command: "sh", Args: []string{"-c", "echo obsolete; exit 2"}}}
			m.goalIteration = 1
			m.goalMaxIterations = 10
			cmd := m.maybeContinueGoalLoop()
			if cmd == nil || !m.goalChecking {
				t.Fatal("check was not scheduled")
			}
			// Queue a real completed subprocess result, then supersede it before delivery.
			result := cmd()
			switch action {
			case "cancel":
				m.handleKey(tea.KeyMsg{Type: tea.KeyCtrlC})
			case "new input":
				m.startRun("new work")
			case "new check":
				m.maybeContinueGoalLoop()
			}
			before := runner.getLastMsg()
			m.Update(result)
			if runner.getLastMsg() != before {
				t.Fatal("obsolete hook result started work")
			}
			m.cancelGoalCheck()
		})
	}
}

func TestCancelGoalCheckCancelsContextAndInvalidatesResults(t *testing.T) {
	entered, cancelled, release := make(chan struct{}), make(chan struct{}), make(chan struct{})
	service := app.New(freshAnswerBackend(), app.Options{MaxIterations: 2, Check: func(ctx context.Context, _ string, _ int) agentio.GoalLoopOutcome {
		close(entered)
		<-ctx.Done()
		close(cancelled)
		<-release
		return agentio.GoalLoopOutcome{Continue: true, NextPrompt: "obsolete"}
	}})
	m := applicationModel(t, service, t.TempDir())
	cmd := m.startRun("work")
	for !m.goalChecking {
		_, cmd = m.Update(cmd())
	}
	<-entered
	m.handleKey(tea.KeyMsg{Type: tea.KeyCtrlC})
	select {
	case <-cancelled:
	case <-time.After(time.Second):
		t.Fatal("checker context not cancelled")
	}
	if !m.running || service.Snapshot().State != app.Cancelling {
		t.Fatal("cancellation released checker ownership before join")
	}
	close(release)
	driveApplication(t, m, cmd)
	if m.goalChecking || m.lastOutcome == nil || m.lastOutcome.Status != agentio.Cancelled || m.lastOutcome.Iterations != 1 {
		t.Fatal("cancelled check continued", m.lastOutcome)
	}
}

func TestGoalResultConsumedOnlyOnce(t *testing.T) {
	m := NewModel(&fakeRunner{}, t.TempDir())
	m.goalIteration = 1
	msg := goalLoopResultMsg{identity: m.identity, outcome: agentio.GoalLoopOutcome{Continue: true, NextPrompt: "next"}}
	m.Update(msg)
	m.Update(msg)
	if m.goalIteration != 2 {
		t.Fatalf("duplicate continuation: iteration %d", m.goalIteration)
	}
}

func TestEventDoneDoesNotReleaseRuntimeBeforeChannelCloses(t *testing.T) {
	release := make(chan struct{})
	backend := applicationBackend{run: func(context.Context, string) (<-chan app.BackendEvent, error) {
		events := make(chan app.BackendEvent)
		go func() {
			events <- app.BackendEvent{Kind: "usage", Done: true}
			<-release
			close(events)
		}()
		return events, nil
	}}
	service := app.New(backend, app.Options{MaxIterations: 1})
	m := applicationModel(t, service, t.TempDir())
	cmd := m.startRun("work")
	stream := m.activeStream
	// Read through the done event while cleanup deliberately retains the channel.
	for {
		msg := cmd()
		_, cmd = m.Update(msg)
		if event, ok := msg.(applicationMsg); ok && event.event.Kind == "usage" {
			break
		}
	}
	if !m.running || m.lastOutcome != nil || service.Snapshot().State != app.Running {
		t.Fatal("done released run before cleanup")
	}
	if _, err := service.Start(context.Background(), "overlap", nil); !errors.Is(err, app.ErrBusy) {
		t.Fatal("overlapping run admitted", err)
	}
	select {
	case <-stream.Terminal:
		t.Fatal("terminal preceded cleanup")
	default:
	}
	close(release)
	driveApplication(t, m, cmd)
	if m.running || m.lastOutcome == nil || m.lastOutcome.Status != agentio.Completed {
		t.Fatal(m.lastOutcome)
	}
}

func TestNewSessionRejectsQueuedGoalContinuation(t *testing.T) {
	m, _, _ := sessionUIFixture(t)
	oldID := m.controller.SessionID()
	m.goalHooks = []config.HookConfig{{Event: "Stop", Command: "sh", Args: []string{"-c", "echo obsolete; exit 2"}}}
	m.goalIteration, m.goalMaxIterations = 1, 10
	check := m.maybeContinueGoalLoop()
	if check == nil {
		t.Fatal("goal check not scheduled")
	}
	result := check()
	change := m.handleCommand("/new")
	if change == nil {
		t.Fatal("session change not scheduled")
	}
	m.Update(result)
	if m.running {
		t.Fatal("queued old goal started during session change")
	}
	m.Update(change())
	if m.controller.SessionID() == oldID || m.sessionChanging {
		t.Fatal("new session did not commit")
	}
	m.Update(result)
	if m.running || m.goalChecking {
		t.Fatal("queued old goal started in new session")
	}
	if entries := m.controller.SessionHistory(); len(entries) != 0 {
		t.Fatalf("old continuation contaminated new session: %v", entries)
	}
}
