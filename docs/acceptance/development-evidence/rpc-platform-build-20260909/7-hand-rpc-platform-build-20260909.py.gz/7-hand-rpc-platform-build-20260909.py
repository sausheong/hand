import os,sys,json,time,subprocess
from pathlib import Path
root=Path('/Users/sausheong/projects/hand');sys.path.insert(0,str(root/'scripts'))
from evidence import source_snapshot
out=Path('/private/tmp/hand-rpc-platform-build-20260909');out.mkdir(exist_ok=False)
roots=[root,Path('/private/tmp/hand-harness-persistence-20260908')]
before={str(p):source_snapshot(p) for p in roots}
(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
version='development-rpc-startup-dirty-20260909'
env={**os.environ,'GOCACHE':'/private/tmp/hand-review-gocache','GOPROXY':'off','PYTHONDONTWRITEBYTECODE':'1'}
commands=[['make','dist','DIST_DIR='+str(out/'dist'),'VERSION='+version],
 [sys.executable,'scripts/smoke_dist.py','--dist',str(out/'dist'),'--version',version,'--commit',commit,'--require-worker']]
report={'qualification':'development_only','source_head':commit,'version':version,'commands':[],'limitations':['Dirty Hand checkout and local unreleased Harness','Build checks on all targets; native help/version smoke only for current host','No full runtime suite, live evaluation or release qualification']}
for i,cmd in enumerate(commands):
 start=time.monotonic()
 with (out/('command-'+str(i)+'.log')).open('wb') as log:
  result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 report['commands'].append({'command':cmd,'exit_code':result.returncode,'seconds':time.monotonic()-start,'log':'command-'+str(i)+'.log'})
 if result.returncode:break
report['source_unchanged']=all(source_snapshot(p)==before[str(p)] for p in roots)
report['source_hashes']={k:v['sha256'] for k,v in before.items()}
report['status']='development_build_smoke_passed' if len(report['commands'])==2 and all(c['exit_code']==0 for c in report['commands']) and report['source_unchanged'] else 'failed'
(out/'run.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
sys.exit(0 if report['status']=='development_build_smoke_passed' else 1)
