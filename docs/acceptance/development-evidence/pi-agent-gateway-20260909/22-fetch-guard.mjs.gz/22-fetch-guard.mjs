const origin="http://127.0.0.1:60664";
const upstream = new URL(origin);
if (upstream.hostname !== '127.0.0.1' || upstream.protocol !== 'http:') throw new Error('loopback required');
const nativeFetch = globalThis.fetch;
globalThis.fetch = async (input, init) => {
 const url = new URL(input instanceof Request ? input.url : String(input));
 if (url.origin !== upstream.origin || url.pathname !== '/v1/messages') throw new Error('non-gateway request forbidden');
 return nativeFetch(input, {...init, redirect:'error'});
};
