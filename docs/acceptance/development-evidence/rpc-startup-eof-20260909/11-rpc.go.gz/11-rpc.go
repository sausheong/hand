package main

import (
	"errors"
	"io"

	"github.com/sausheong/hand/internal/app"
	handrpc "github.com/sausheong/hand/internal/rpc"
)

type stdioRPC struct {
	input  io.ReadCloser
	output io.WriteCloser
}

func (s *stdioRPC) Read(p []byte) (int, error)  { return s.input.Read(p) }
func (s *stdioRPC) Write(p []byte) (int, error) { return s.output.Write(p) }
func (s *stdioRPC) Close() error                { return errors.Join(s.input.Close(), s.output.Close()) }
func runRPC(transport *handrpc.PreparedTransport, controller *app.Controller, storeDir, workspace string) error {
	ledger, err := handrpc.OpenWorkspaceLedger(storeDir, workspace)
	if err != nil {
		return err
	}
	defer ledger.Close()
	dispatcher := handrpc.NewControllerDispatcher(controller, ledger)
	return handrpc.ServePrepared(transport, dispatcher, handrpc.TransportOptions{})
}
