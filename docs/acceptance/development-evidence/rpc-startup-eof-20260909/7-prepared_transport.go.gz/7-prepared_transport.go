package rpc

import (
	"context"
	"io"
	"sync"

	"github.com/sausheong/hand/protocol"
)

type incomingFrame struct {
	data []byte
	err  error
}

// PreparedTransport owns a bounded reader before application construction.
// Disconnect cancels startup through the supplied callback; ServePrepared
// transfers that callback to the dispatcher without starting another reader.
// Close on conn must unblock both Read and Write.
type PreparedTransport struct {
	ctx                   context.Context
	cancel                context.CancelFunc
	conn                  io.ReadWriteCloser
	incoming              chan incomingFrame
	readerDone, watchDone chan struct{}
	mu                    sync.Mutex
	disconnected          bool
	onDisconnect          func()
}

func PrepareTransport(parent context.Context, conn io.ReadWriteCloser, onDisconnect func()) *PreparedTransport {
	ctx, cancel := context.WithCancel(parent)
	t := &PreparedTransport{ctx: ctx, cancel: cancel, conn: conn, incoming: make(chan incomingFrame, 1),
		readerDone: make(chan struct{}), watchDone: make(chan struct{}), onDisconnect: onDisconnect}
	go func() { defer close(t.watchDone); <-ctx.Done(); t.disconnect(); _ = conn.Close() }()
	go func() {
		defer close(t.readerDone)
		reader := protocol.NewReader(conn)
		for {
			data, err := reader.ReadFrame()
			if err != nil {
				t.disconnect()
			}
			select {
			case t.incoming <- incomingFrame{data, err}:
			case <-ctx.Done():
				return
			}
			if err != nil {
				return
			}
		}
	}()
	return t
}

func (t *PreparedTransport) disconnect() {
	t.mu.Lock()
	t.disconnected = true
	callback := t.onDisconnect
	t.mu.Unlock()
	if callback != nil {
		callback()
	}
}

func (t *PreparedTransport) transfer(callback func()) {
	t.mu.Lock()
	t.onDisconnect = callback
	disconnected := t.disconnected
	t.mu.Unlock()
	if disconnected && callback != nil {
		callback()
	}
}

func (t *PreparedTransport) Close() error {
	t.cancel()
	err := t.conn.Close()
	<-t.watchDone
	<-t.readerDone
	return err
}
