//go:build !darwin && !linux

package main

import (
	"errors"
	"io"
)

func prepareStdioRPC() (io.ReadWriteCloser, error) {
	return nil, errors.New("interruptible RPC stdio requires a supported Linux or macOS platform")
}
