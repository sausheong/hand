package app

import (
	"context"
	"errors"
	"github.com/sausheong/harness/budget"
	"github.com/sausheong/harness/llm/llmtest"
	"testing"
	"time"

	"github.com/sausheong/harness/compaction"
	"github.com/sausheong/harness/llm"
	"github.com/sausheong/harness/runtime"
	"github.com/sausheong/harness/session"
	"github.com/sausheong/harness/tool"
)

func TestSelectedRunBudgetGovernsManualCompaction(t *testing.T) {
	ctx := context.Background()
	sess := session.NewSession("hand", "manual-budget")
	for i := 0; i < 10; i++ {
		sess.Append(session.UserMessageEntry("task detail"))
		sess.Append(session.AssistantMessageEntry("work detail"))
	}
	provider := &focusProvider{}
	rt := &runtime.Runtime{Session: sess, Compaction: &compaction.Manager{Summarizer: &compaction.Summarizer{Provider: provider, Model: "summary-fixture", MaxOutputTokens: 1024}, PreserveTurns: 2}}
	c := &Controller{Rt: rt, Owner: NewHarness(rt, nil, nil, t.TempDir(), 1)}
	if err := c.DecideRunTokenBudget(ctx, "job", 1); err != nil {
		t.Fatal(err)
	}
	if err := c.SelectRunBudget(ctx, "job"); err != nil {
		t.Fatal(err)
	}
	before := len(sess.View())
	result, _ := c.CompactWithFocus(ctx, "keep evidence")
	if len(provider.requests) != 0 || result.Compacted || len(sess.View()) != before {
		t.Fatal("manual compaction bypassed selected run ceiling")
	}
	state, err := c.RunBudget(ctx, "job")
	if err != nil || !state.Tokens.Exhausted {
		t.Fatalf("missing exhaustion %+v %v", state, err)
	}
	if err = c.DecideRunTokenBudget(ctx, "job", 100000); err != nil {
		t.Fatal(err)
	}
	result, err = c.CompactWithFocus(ctx, "keep evidence")
	if err != nil || !result.Compacted || len(provider.requests) != 1 {
		t.Fatalf("explicit resume %+v %v", result, err)
	}
	state, err = c.RunBudget(ctx, "job")
	if err != nil || len(state.Tokens.Attempts) != 1 || state.Tokens.Attempts[0].Category != llm.CallCompaction {
		t.Fatalf("summary not accounted %+v %v", state, err)
	}
}
func TestSelectedRunBudgetGovernsControllerAdapter(t *testing.T) {
	ctx := context.Background()
	p := &persistedUsageProvider{}
	rt := &runtime.Runtime{Session: session.NewSession("hand", "adapter"), LLM: p, Tools: tool.NewRegistry(), Model: "fixture", MaxTurns: 1}
	c := &Controller{Rt: rt, Owner: NewHarness(rt, nil, nil, t.TempDir(), 1)}
	if err := c.DecideRunTokenBudget(ctx, "job", 1); err != nil {
		t.Fatal(err)
	}
	if err := c.SelectRunBudget(ctx, "job"); err != nil {
		t.Fatal(err)
	}
	stream, err := c.Owner.Start(ctx, "must not dispatch", nil)
	if err != nil {
		t.Fatal(err)
	}
	for range stream.Events {
	}
	outcome, err := stream.Wait()
	if err != nil || !errors.Is(outcome.Cause, runtime.ErrRunTokenExhausted) {
		t.Fatalf("service lost run-budget refusal: %+v %v", outcome, err)
	}

}

type budgetWaitingProvider struct {
	llmtest.Base
	stopped chan struct{}
}

func (p *budgetWaitingProvider) ChatStream(ctx context.Context, _ llm.ChatRequest) (<-chan llm.ChatEvent, error) {
	ch := make(chan llm.ChatEvent)
	go func() { defer close(ch); <-ctx.Done(); close(p.stopped) }()
	return ch, nil
}
func TestDirectBudgetAdaptersRetainDeadlineCause(t *testing.T) {
	for _, adapter := range []string{"backend", "service"} {
		t.Run(adapter, func(t *testing.T) {
			ctx := context.Background()
			p := &budgetWaitingProvider{stopped: make(chan struct{})}
			rt := &runtime.Runtime{Session: session.NewSession("hand", "adapter-time"), LLM: p, Tools: tool.NewRegistry(), Model: "fixture", MaxTurns: 1}
			c := &Controller{Rt: rt, Owner: NewHarness(rt, nil, nil, t.TempDir(), 1)}
			if err := c.DecideRunTimeBudget(ctx, "job", 1); err != nil {
				t.Fatal(err)
			}
			if err := c.SelectRunBudget(ctx, "job"); err != nil {
				t.Fatal(err)
			}
			found := false
			if adapter == "backend" {
				events, err := (&HarnessBackend{Runtime: rt}).Run(ctx, "wait", nil)
				if err != nil {
					t.Fatal(err)
				}
				for e := range events {
					if errors.Is(e.Err, budget.ErrRunTimeExhausted) {
						found = true
					}
				}
			} else {
				stream, err := c.Owner.Start(ctx, "wait", nil)
				if err != nil {
					t.Fatal(err)
				}
				for range stream.Events {
				}
				outcome, err := stream.Wait()
				if err != nil {
					t.Fatal(err)
				}
				found = errors.Is(outcome.Cause, budget.ErrRunTimeExhausted)

			}
			if !found {
				t.Fatal("adapter dropped deadline error")
			}
			select {
			case <-p.stopped:
			case <-time.After(time.Second):
				t.Fatal("provider not stopped")
			}
		})
	}
}
