import os, sys, json, subprocess, hashlib
from pathlib import Path
root=Path('/Users/sausheong/projects/hand')
sys.path.insert(0,str(root/'scripts'))
from evidence import source_snapshot, coverage_metrics
out=Path('/private/tmp/hand-published-integration-final-20260910');out.mkdir()
e=dict(os.environ,**json.loads((root/'docs/acceptance/current-native-suite.json').read_text())['environment'])
e.update(GOWORK='off',GOPROXY='off',GOCACHE='/private/tmp/hand-review-gocache')
e['HAND_TEST_WORKER_BINARY']=str(out/'worker');e['HAND_TEST_EXTENSION_PEER_BINARY']=str(out/'peer.test')
report={'source_before':source_snapshot(root),'commands':[]}
report['module']=json.loads(subprocess.check_output(['go','list','-m','-json','github.com/sausheong/harness'],cwd=root,env=e))
assert report['module']['Version']=='v0.4.0' and 'Replace' not in report['module']
def run(label,argv,env=e):
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 report['commands'].append(dict(label=label,argv=argv,exit_code=r.returncode))
 (out/'run.json').write_text(json.dumps(report,indent=2)+'\n')
 if r.returncode:raise RuntimeError(label+' failed')
 print(label+' passed',flush=True)
try:
 cross=dict(e,GOOS='linux',GOARCH='arm64',CGO_ENABLED='0')
 run('worker-build',['go','build','-o',e['HAND_TEST_WORKER_BINARY'],'./cmd/hand-tool-worker'],cross)
 run('peer-build',['go','test','-c','-o',e['HAND_TEST_EXTENSION_PEER_BINARY'],'./internal/app'],cross)
 report['fixtures']={k:hashlib.sha256(Path(e[k]).read_bytes()).hexdigest() for k in ['HAND_TEST_WORKER_BINARY','HAND_TEST_EXTENSION_PEER_BINARY']}
 run('vet',['go','vet','./...'])
 run('tests',['go','test','-p=1','-race','-count=1','-timeout=15m','-coverpkg=./...','-coverprofile='+str(out/'coverage.out'),'-json','./...'])
 report['coverage']=coverage_metrics((out/'coverage.out').read_text())
 report['status']='tests_passed_pending_event_and_coverage_review'
finally:
 report['source_after']=source_snapshot(root)
 report['source_unchanged']=report['source_before']==report['source_after']
 (out/'run.json').write_text(json.dumps(report,indent=2)+'\n')
