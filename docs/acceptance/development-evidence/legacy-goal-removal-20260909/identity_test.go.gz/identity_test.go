package tui

import (
	"context"
	"encoding/json"
	"strings"
	"testing"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/sausheong/hand/internal/agentio"
	"github.com/sausheong/hand/internal/app"
	"github.com/sausheong/harness/runtime"
	"github.com/sausheong/harness/session"
)

func TestStaleStreamAndApprovalCannotAffectCurrentRun(t *testing.T) {
	for _, change := range []string{"session", "run", "generation"} {
		t.Run(change, func(t *testing.T) {
			m := NewModel(&fakeRunner{}, t.TempDir())
			m.running = true
			m.identity.RunID = 2
			old := m.identity
			switch change {
			case "session":
				old.SessionID = "old"
			case "run":
				old.RunID--
			case "generation":
				old.Generation++
			}
			m.Update(runEventMsg{identity: old, event: runtime.AgentEvent{Type: runtime.EventTextDelta, Text: "obsolete"}})
			m.Update(runEndedMsg{identity: old})
			response := make(chan agentio.Decision, 1)
			m.Update(agentio.ApprovalRequest{Identity: old, Tool: "bash", Respond: response})
			if !m.running || m.streamBuf.Len() != 0 || m.pending != nil {
				t.Fatal("stale message mutated current run")
			}
			select {
			case d := <-response:
				if d != agentio.DecisionDeny {
					t.Fatal("stale approval allowed")
				}
			default:
				t.Fatal("stale approval was not released")
			}
		})
	}
}

func TestCancellationRejectsQueuedMessagesAndWaitsForJoin(t *testing.T) {
	m := NewModel(&fakeRunner{}, t.TempDir())
	m.running = true
	ctx, cancel := context.WithCancel(context.Background())
	m.cancel = cancel
	response := make(chan agentio.Decision, 1)
	m.Update(agentio.ApprovalRequest{Identity: m.identity, Tool: "bash", Input: json.RawMessage(`{}`), Respond: response})
	m.handleKey(tea.KeyMsg{Type: tea.KeyCtrlC})
	if ctx.Err() == nil || m.pending != nil || !m.running {
		t.Fatal("cancel did not dismiss approval and retain run ownership")
	}
	m.Update(runEventMsg{identity: m.identity, event: runtime.AgentEvent{Type: runtime.EventTextDelta, Text: "late"}})
	if m.streamBuf.Len() != 0 {
		t.Fatal("cancelled run accepted late output")
	}
	m.Update(runEndedMsg{identity: m.identity})
	if m.running {
		t.Fatal("channel closure did not release run")
	}
	_, cmd := m.Update(runEndedMsg{identity: m.identity})
	if cmd != nil {
		t.Fatal("duplicate closure scheduled more work")
	}
}

func TestSessionAndModelChangesInvalidateQueuedGoal(t *testing.T) {
	for _, command := range []string{"/new", "/model test/new"} {
		t.Run(command, func(t *testing.T) {
			service := app.New(freshAnswerBackend(), app.Options{MaxIterations: 2, Check: func(_ context.Context, _ string, iteration int) agentio.GoalLoopOutcome {
				if iteration == 1 {
					return agentio.GoalLoopOutcome{Continue: true, NextPrompt: "obsolete"}
				}
				return agentio.GoalLoopOutcome{Verified: true}
			}})
			m := applicationModel(t, service, t.TempDir())
			store := session.NewStore(t.TempDir())
			sess, err := store.Load("hand", "test")
			if err != nil {
				t.Fatal(err)
			}
			m.SetController(&Controller{Rt: &runtime.Runtime{AgentID: "hand", Session: sess, Provider: "test", Model: "old"}, Store: store, SessionKey: "test", Owner: service})
			result := captureContinuation(t, m, m.startRun("old work"))
			cmd := m.handleCommand(command)
			m.Update(result)
			if m.running {
				t.Fatal("old goal restarted after command")
			}
			if cmd != nil {
				m.Update(cmd())
			}
			m.CloseApplication()
			if err := m.controller.Rt.Session.Close(); err != nil {
				t.Fatal(err)
			}
		})
	}
}

func TestRunningSlashCommandCannotSwitchSessionAndQuitJoins(t *testing.T) {
	m := NewModel(&fakeRunner{}, t.TempDir())
	m.running = true
	ctx, cancel := context.WithCancel(context.Background())
	m.cancel = cancel
	m.handleCommand("/new")
	if !strings.Contains(strings.Join(m.transcript, "\n"), "run still active") {
		t.Fatal("running command was not guarded")
	}
	if cmd := m.handleCommand("/quit"); cmd != nil || ctx.Err() == nil {
		t.Fatal("quit did not request cancellation first")
	}
	_, cmd := m.Update(runEndedMsg{identity: m.identity})
	if cmd == nil {
		t.Fatal("quit never completed after join")
	}
	if _, ok := cmd().(tea.QuitMsg); !ok {
		t.Fatal("expected quit")
	}
}
