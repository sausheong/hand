// Package tui is Hand's Bubble Tea terminal UI.
package tui

import (
	tea "github.com/charmbracelet/bubbletea"
	"github.com/sausheong/hand/internal/agentio"
	"github.com/sausheong/hand/internal/sessionio"
	"github.com/sausheong/harness/compaction"
	"github.com/sausheong/harness/runtime"
)

// runEndedMsg marks that an AgentEvent channel has closed. harness's
// Run goroutine can exit several error paths without ever emitting a
// terminal EventDone (see runtime.go's early r.emit(EventError); return
// paths), so relying on EventDone alone to know a turn ended would
// leave the UI stuck in the "running" state on those paths. StreamEvents
// sends this exactly once, after ranging over events completes.
type runEndedMsg struct{ identity agentio.RunIdentity }
type runEventMsg struct {
	identity agentio.RunIdentity
	event    runtime.AgentEvent
}

// programSender is satisfied by *tea.Program. Declared as an interface
// (rather than taking *tea.Program directly) so StreamEvents is
// testable without a real terminal.
type programSender interface {
	Send(msg tea.Msg)
}

// StreamEvents forwards every AgentEvent from events into p as a
// tea.Msg, in order, then sends a single runEndedMsg once events
// closes. Intended to run in its own goroutine for the lifetime of one
// agent turn — an ordinary tea.Cmd cannot represent an unbounded stream
// like this, since a Cmd only ever produces one terminal Msg.
func StreamEvents(p programSender, events <-chan runtime.AgentEvent, identity agentio.RunIdentity) {
	for ev := range events {
		p.Send(runEventMsg{identity: identity, event: ev})
	}
	p.Send(runEndedMsg{identity: identity})
}

// compactResultMsg releases the operation only after its worker has returned.
// Cancellation does not permit another operation to race a still-exiting worker.
type compactResultMsg struct {
	usage      sessionio.UsageSummary
	usageKnown bool
	usageErr   error
	identity   agentio.RunIdentity
	generation uint64
	result     compaction.Result
	err        error
}
