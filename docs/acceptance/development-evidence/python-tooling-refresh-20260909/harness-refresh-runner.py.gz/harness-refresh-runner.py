import sys,json,os,subprocess,time
from pathlib import Path
hand=Path('/Users/sausheong/projects/hand');root=Path('/private/tmp/hand-harness-persistence-20260908');out=Path('/private/tmp/hand-harness-qualification-refresh-20260909');out.mkdir()
sys.dont_write_bytecode=True;sys.path.insert(0,str(hand/'scripts'))
from evidence import source_snapshot,coverage_metrics
from validate import inventory_names,check_events
settings=json.loads((hand/'docs/acceptance/harness-current-native-suite.json').read_text())['environment']
env={k:os.environ[k] for k in ['PATH','HOME','TMPDIR'] if k in os.environ};env.update(settings)
report={'status':'running','environment':env,'source_before':source_snapshot(root),'commands':[]}
def run(argv,label):
 start=time.monotonic()
 with (out/label).open('wb') as stream:
  result=subprocess.run(argv,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 report['commands'].append({'argv':argv,'log':str(out/label),'exit_code':result.returncode,'seconds':time.monotonic()-start})
 return result.returncode
try:
 if run(['go','list','./...'],'packages.txt'):raise RuntimeError('package inventory failed')
 expected=set()
 for i,pkg in enumerate((out/'packages.txt').read_text().splitlines()):
  label=f'inventory-{i}.txt'
  if run(['go','test','-list','^(Test|Example|Fuzz)',pkg],label):raise RuntimeError('test inventory failed')
  expected.update((pkg,name) for name in inventory_names((out/label).read_text()))
 if not expected:raise RuntimeError('empty inventory')
 (out/'inventory.json').write_text(json.dumps(sorted(expected),indent=2)+'\n')
 code=run(['go','test','-p=1','-race','-count=1','-timeout=15m','-coverpkg=./...','-coverprofile='+str(out/'coverage.out'),'-json','./...'],'tests.jsonl')
 events=[]
 for line in (out/'tests.jsonl').read_text().splitlines():
  if line.startswith('{'):events.append(json.loads(line))
 report['tests']=check_events(events,expected)
 if (out/'coverage.out').exists():report['coverage']=coverage_metrics((out/'coverage.out').read_text())
 report['source_after']=source_snapshot(root);report['sources_unchanged']=report['source_before']==report['source_after']
 report['status']='development_passed' if code==0 and report['sources_unchanged'] and not any(report['tests'][k] for k in ['skipped','failed','missing','unfinished','missing_packages']) else 'failed'
except Exception as error:
 report['status']='error';report['error']=str(error)
finally:
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'status':report['status'],'report':str(out/'report.json'),'tests':report.get('tests',{})}))
sys.exit(0 if report['status']=='development_passed' else 1)
