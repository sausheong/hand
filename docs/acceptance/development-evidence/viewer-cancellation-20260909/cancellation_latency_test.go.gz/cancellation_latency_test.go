package tui

import (
	"context"
	"sort"
	"testing"
	"time"

	tea "github.com/charmbracelet/bubbletea"
	"github.com/sausheong/hand/internal/agentio"
	"github.com/sausheong/hand/internal/app"
)

// Measure delivery through the production Model and Service to the context
// observed by an active backend/checker. This does not measure provider/network
// cancellation or descendant cleanup, which require separate native journeys.
func TestApplicationCancellationInitiationLatency(t *testing.T) {
	for _, phase := range []string{"backend", "checker"} {
		for _, action := range []string{"ctrl_c", "close", "viewer", "viewer_search"} {
			t.Run(phase+"/"+action, func(t *testing.T) {
				samples := make([]float64, 0, 30)
				for trial := 0; trial < 30; trial++ {
					samples = append(samples, measureCancellationSignal(t, phase, action))
				}
				sort.Float64s(samples)
				p95 := samples[28] // nearest-rank ceil(30 * 0.95)
				t.Logf("cancel_start_ms_sorted=%v p95_ms=%f trials=%d", samples, p95, len(samples))
				if p95 > 1000 {
					t.Fatalf("cancellation initiation p95 %f ms exceeds 1000 ms", p95)
				}
			})
		}
	}
}

func measureCancellationSignal(t *testing.T, phase, action string) float64 {
	t.Helper()
	started := make(chan struct{})
	observed := make(chan time.Time, 1)
	wait := func(ctx context.Context) {
		close(started)
		<-ctx.Done()
		observed <- time.Now()
	}
	backend := applicationBackend{run: func(ctx context.Context, _ string) (<-chan app.BackendEvent, error) {
		ch := make(chan app.BackendEvent, 1)
		if phase == "backend" {
			go func() { wait(ctx); close(ch) }()
		} else {
			ch <- app.BackendEvent{Done: true}
			close(ch)
		}
		return ch, nil
	}}
	options := app.Options{SessionID: "latency", MaxIterations: 1}
	if phase == "checker" {
		options.Check = func(ctx context.Context, _ string, _ int) agentio.GoalLoopOutcome {
			wait(ctx)
			return agentio.GoalLoopOutcome{}
		}
	}
	m := NewModel(nil, t.TempDir())
	m.SetService(app.New(backend, options))
	m.startRun("cancellation latency")
	defer m.CloseApplication()
	stream := m.activeStream
	select {
	case <-started:
	case <-time.After(3 * time.Second):
		t.Fatal("backend/checker did not start")
	}
	start := time.Now()
	if action == "viewer" || action == "viewer_search" {
		m.outputView = &outputViewer{searching: action == "viewer_search"}
	}
	if action != "close" {
		m.Update(tea.KeyMsg{Type: tea.KeyCtrlC})
	} else {
		m.CloseApplication()
	}
	var signal time.Time
	select {
	case signal = <-observed:
	case <-time.After(3 * time.Second):
		t.Fatal("cancellation did not reach backend/checker context")
	}
	select {
	case <-stream.Done:
	case <-time.After(3 * time.Second):
		t.Fatal("cancelled backend/checker did not join")
	}
	outcome, err := stream.Wait()
	if err != nil || outcome.Status != agentio.Cancelled {
		t.Fatalf("cancellation outcome=%+v err=%v", outcome, err)
	}
	return float64(signal.Sub(start).Nanoseconds()) / 1e6
}
