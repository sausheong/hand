package llm

import (
	"context"
	"crypto/rand"
	"fmt"
	"sync"
)

type CallCategory string

const (
	CallGeneration CallCategory = "generation"
	CallRetry      CallCategory = "retry"
	CallCompaction CallCategory = "compaction"
)

// RequestUsage represents one attempted provider call. Nil Usage explicitly
// means unavailable, including potentially billable failures; it is not zero.
// InputTokens includes cached input. Cache fields are subsets, not additions.
type RequestUsage struct {
	ID       string       `json:"request_id"`
	Model    string       `json:"model"`
	Category CallCategory `json:"category"`
	Status   string       `json:"status"`
	Source   string       `json:"source"`
	Usage    *Usage       `json:"usage"`
}

type usageObserverKey struct{}

// WithUsageObserver chains observers. Callbacks can run concurrently and must
// not mutate their record. Each callback completes before its terminal event
// is forwarded to the consumer.
func WithUsageObserver(ctx context.Context, observer func(RequestUsage)) context.Context {
	previous, _ := ctx.Value(usageObserverKey{}).(func(RequestUsage))
	return context.WithValue(ctx, usageObserverKey{}, func(record RequestUsage) {
		if previous != nil {
			previous(record)
		}
		if observer != nil {
			observer(record)
		}
	})
}

// ObserveChat observes streaming and non-streaming adapters using one contract.
// Providers must terminate after EventDone/EventError and honour cancellation.
func ObserveChat(ctx context.Context, req ChatRequest, category CallCategory, call func(context.Context, ChatRequest) (<-chan ChatEvent, error)) (<-chan ChatEvent, error) {
	observer, _ := ctx.Value(usageObserverKey{}).(func(RequestUsage))
	if observer == nil {
		return call(ctx, req)
	}
	record := RequestUsage{ID: rand.Text(), Model: req.Model, Category: category, Source: "unavailable"}
	publish := func(status string, usage *Usage) {
		record.Status = status
		if usage != nil {
			copy := *usage
			record.Usage = &copy
			record.Source = "reported"
		}
		observer(record)
	}
	source, err := call(ctx, req)
	if err != nil {
		status := "failed"
		if ctx.Err() != nil {
			status = "cancelled"
		}
		publish(status, nil)
		return nil, err
	}
	if source == nil {
		publish("failed", nil)
		return nil, fmt.Errorf("provider returned a nil event stream")
	}
	out := make(chan ChatEvent)
	go func() {
		defer close(out)
		var usage *Usage
		for {
			select {
			case <-ctx.Done():
				publish("cancelled", usage)
				return
			case event, ok := <-source:
				if !ok {
					publish("failed", usage)
					select {
					case out <- ChatEvent{Type: EventError, Error: fmt.Errorf("provider stream closed without terminal event")}:
					case <-ctx.Done():
					}
					return
				}
				if event.Usage != nil {
					copy := *event.Usage
					usage = &copy
				}
				terminal := event.Type == EventDone || event.Type == EventError
				if terminal {
					status := "completed"
					if event.Type == EventError {
						status = "failed"
					}
					publish(status, usage)
				}
				select {
				case out <- event:
				case <-ctx.Done():
					if !terminal {
						publish("cancelled", usage)
					}
					return
				}
				if terminal {
					return
				}
			}
		}
	}()
	return out, nil
}

// UsageLedger keeps immutable request records and a reported-only total.
// Unknown requests remain visible through Records rather than being priced as
// free. Create a ledger per bounded operation, not a process-global history.
type UsageLedger struct {
	mu      sync.Mutex
	records []RequestUsage
	total   *Usage
}

func (l *UsageLedger) Record(record RequestUsage) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if record.Usage != nil {
		u := *record.Usage
		record.Usage = &u
		if l.total == nil {
			l.total = &Usage{}
		}
		l.total.InputTokens += u.InputTokens
		l.total.OutputTokens += u.OutputTokens
		l.total.CacheCreationInputTokens += u.CacheCreationInputTokens
		l.total.CacheReadInputTokens += u.CacheReadInputTokens
	}
	l.records = append(l.records, record)
}
func (l *UsageLedger) Total() *Usage {
	l.mu.Lock()
	defer l.mu.Unlock()
	if l.total == nil {
		return nil
	}
	u := *l.total
	return &u
}
func (l *UsageLedger) Records() []RequestUsage {
	l.mu.Lock()
	defer l.mu.Unlock()
	out := append([]RequestUsage(nil), l.records...)
	for i := range out {
		if out[i].Usage != nil {
			u := *out[i].Usage
			out[i].Usage = &u
		}
	}
	return out
}
