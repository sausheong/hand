package rpc

import (
	"context"
	"errors"
	"io"
	"sync"

	"github.com/sausheong/hand/protocol"
)

type incomingFrame struct {
	data []byte
	err  error
}

var ErrStartupBacklog = errors.New("RPC startup request queue full; wait for hello response before sending more requests")

// PreparedTransport owns a bounded reader before application construction.
// Disconnect cancels startup through the supplied callback; ServePrepared
// transfers that callback to the dispatcher without starting another reader.
// Close on conn must unblock both Read and Write.
type PreparedTransport struct {
	ctx                   context.Context
	cancel                context.CancelFunc
	conn                  io.ReadWriteCloser
	incoming              chan incomingFrame
	readerDone, watchDone chan struct{}
	mu                    sync.Mutex
	disconnected          bool
	starting              bool
	startupError          error
	onDisconnect          func()
}

func PrepareTransport(parent context.Context, conn io.ReadWriteCloser, onDisconnect func()) *PreparedTransport {
	return prepareTransport(parent, conn, onDisconnect, true)
}

func prepareTransport(parent context.Context, conn io.ReadWriteCloser, onDisconnect func(), starting bool) *PreparedTransport {
	ctx, cancel := context.WithCancel(parent)
	t := &PreparedTransport{ctx: ctx, cancel: cancel, conn: conn, incoming: make(chan incomingFrame, 1),
		readerDone: make(chan struct{}), watchDone: make(chan struct{}), onDisconnect: onDisconnect, starting: starting}
	go func() { defer close(t.watchDone); <-ctx.Done(); t.disconnect(); _ = conn.Close() }()
	go func() {
		defer close(t.readerDone)
		reader := protocol.NewReader(conn)
		for {
			data, err := reader.ReadFrame()
			if err != nil {
				t.disconnect()
			}
			select {
			case t.incoming <- incomingFrame{data, err}:
			case <-ctx.Done():
				return
			default:
				// A second complete frame before handoff would block this
				// reader from seeing EOF while construction waits on MCP.
				// After handoff, preserve the normal bounded backpressure.
				if err == nil && t.rejectStartupBacklog() {
					return
				}
				select {
				case t.incoming <- incomingFrame{data, err}:
				case <-ctx.Done():
					return
				}
			}
			if err != nil {
				return
			}
		}
	}()
	return t
}

func (t *PreparedTransport) rejectStartupBacklog() bool {
	t.mu.Lock()
	starting := t.starting
	if starting {
		t.startupError = ErrStartupBacklog
	}
	t.mu.Unlock()
	if starting {
		t.disconnect()
		t.cancel()
	}
	return starting
}

func (t *PreparedTransport) StartupError() error {
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.startupError
}

func (t *PreparedTransport) disconnect() {
	t.mu.Lock()
	t.disconnected = true
	callback := t.onDisconnect
	t.mu.Unlock()
	if callback != nil {
		callback()
	}
}

func (t *PreparedTransport) transfer(callback func()) {
	t.mu.Lock()
	t.starting = false
	t.onDisconnect = callback
	disconnected := t.disconnected
	t.mu.Unlock()
	if disconnected && callback != nil {
		callback()
	}
}

func (t *PreparedTransport) Close() error {
	t.cancel()
	err := t.conn.Close()
	<-t.watchDone
	<-t.readerDone
	return err
}
